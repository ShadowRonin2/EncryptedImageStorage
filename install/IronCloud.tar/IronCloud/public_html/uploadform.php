<form enctype="multipart/form-data" action="upload.php" method="POST">
 Please choose a file: <input name="userfile" type="file" /><br />
 <input type="submit" value="Upload" />
 </form> 
