<?php
define("HOST", "localhost");
define("USER", "loginuser");
define("PASSWORD", "examplepassword");
define("DATABASE", "login");

define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");

define("SECURE", FALSE);
